/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva2_8__herencia_interfaces;

/**
 *
 * @author Alex Montes
 */
public class EVA2_8__HERENCIA_INTERFACES {
     int A = 10;
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Prueba prueba = new Prueba();
        prueba.meotodoA();
        prueba.metodoB();
        //System.out.println(A);
    }
    
}
class Prueba implements B{

    @Override
    public void metodoB() {
        
    }

    @Override
    public void meotodoA() {
        
    }
    
}

interface A{
    public void meotodoA();
}

interface B extends A{
    public void metodoB();
}

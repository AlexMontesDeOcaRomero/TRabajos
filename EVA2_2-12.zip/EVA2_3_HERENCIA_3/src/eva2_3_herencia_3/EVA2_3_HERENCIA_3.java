/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva2_3_herencia_3;

/**
 *
 * @author Alex Montes
 */
public class EVA2_3_HERENCIA_3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Animal animal = new Animal();
        animal.mover();
        Vertebrado verte = new Vertebrado();
        verte.tenerESqueleto();
        Mamifero mamifero = new Mamifero();
        mamifero.tenerPelo();
        Primates primate = new Primates();
        primate.agarrarObjetos();
        Humano humano = new Humano();
        humano.pensar();
    }
    
class Humano extends Primates{
    public Humano(){
        System.out.println("HUMANO");
    }
    public void pensar(){
        System.out.println("PENSAR");
    }
}    
    
}
class Mamifero extends Vertebrado{
   public Mamifero(){
       super();
       System.out.println("MAMIFERO");
   }
   public void tenerPelo(){
       System.out.println("TENER PELO");
   }
   
}
class Primates extends Mamifero{
    public Primates(){
        System.out.println("PRIMATES");
    }
    public void agarrarObjetos(){
    System.out.println("AGARRAR OBJETOS");
}
    
}

class Vertebrado extends Animal{
    public Vertebrado(){
        super();
        System.out.println("VERTEBRADO");
    }
    public void tenerESqueleto(){
        System.out.println("VERTEBRADO: tiene esqueleto");
    }
}

class Animal{
    public void animal(){
    System.out.println("ANIMAL");
}
    
    public void mover(){
        System.out.println("ANIMAL: movimiento");
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva2_4_herencia_vehiculos;

/**
 *
 * @author Alex Montes
 */
public class EVA2_4_HERENCIA_VEHICULOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
    }
    
}

class Vehiculos{
    private String tipoCombustible;
    private int numeroLlanta;
    private double capacidadMotor;
    private int cilindrosMotor;
    private int capacidadPasajeros;
    private String marca;
    private String modelo;
    private int ano;
    
    public Vehiculos(){
        tipoCombustible = "";
        numeroLlanta = 0;
        capacidadMotor = 0.0;
        cilindrosMotor = 0;
        capacidadPasajeros = 0;
        marca = "";
        modelo = "";
        ano = 0;
    }
    
    public Vehiculos(String tipoCombustible, int numeroLlanta, double capacidadMotor, int cilindrosMotor, int capacidadPasajeros, String marca, String modelo, int ano){
        this.tipoCombustible = tipoCombustible;
        this.numeroLlanta = numeroLlanta;
        this.capacidadMotor = capacidadMotor;
        this.cilindrosMotor = cilindrosMotor;
        this.capacidadPasajeros = capacidadPasajeros;
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
    }
    
    public void imprimirDatos(){
        System.out.println("Tipo de combustible: " + tipoCombustible);
        System.out.println("Numero de llanta: " + numeroLlanta);
        System.out.println("Capacidad en litros del motor: " + capacidadMotor);
        System.out.println("Cilindros del motor: " + cilindrosMotor);
        System.out.println("Capacidad del carro para los pasajeros: " + capacidadPasajeros);
        System.out.println("Marca: " + marca);
        System.out.println("Modelo: " + modelo);
        System.out.println("Ano: " + ano);
    }
}
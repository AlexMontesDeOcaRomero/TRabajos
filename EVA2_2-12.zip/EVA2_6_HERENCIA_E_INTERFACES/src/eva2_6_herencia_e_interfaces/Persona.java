/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eva2_6_herencia_e_interfaces;

/**
 *
 * @author Alex Montes
 */
public class Persona {
    private String nombre;
    private int Edad;
    
    public class Persona(){
    this.nombre = "";
    this.Edad = 0;
}
    

}


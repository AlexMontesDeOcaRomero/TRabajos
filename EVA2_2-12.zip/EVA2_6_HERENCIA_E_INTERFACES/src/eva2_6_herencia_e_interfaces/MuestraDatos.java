/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package eva2_6_herencia_e_interfaces;

/**
 *
 * @author Alex Montes
 */
public interface MuestraDatos {
    public void imprimirDatos();
}

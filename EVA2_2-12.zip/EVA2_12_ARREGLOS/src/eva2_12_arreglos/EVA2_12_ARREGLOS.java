/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva2_12_arreglos;

import java.util.Scanner;

/**
 *
 * @author Alex Montes
 */
public class EVA2_12_ARREGLOS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int[] arregloEdad = new int[32];//4 bytes ocupa un entero, 128 bytes
        Scanner input = new Scanner (System.in);
        // 32 capturas --> for
        for(int i= 0; i <32; i++){ //i --> index/indice
        System.out.println("Cual es tu edad?");
        arregloEdad[i] = input.nextInt();
    }
       for(int i = 0; i < 32; i++){
           System.out.println("[" + arregloEdad[i] + "]");
       } 
        
    }
    
}

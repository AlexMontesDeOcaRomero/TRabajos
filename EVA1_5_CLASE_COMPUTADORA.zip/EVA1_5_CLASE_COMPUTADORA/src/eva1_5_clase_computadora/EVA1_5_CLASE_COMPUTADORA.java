/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_5_clase_computadora;

/**
 *
 * @author Alex Montes
 */
public class EVA1_5_CLASE_COMPUTADORA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        computadora PC1 = new computadora();
        PC1.setGrafica("NVIDIA 1050ti");
        PC1.setProcesador("Rayzen 5 5600g");
        PC1.setMotherboard("A320M-S2H");
        PC1.setFuente("EVGA 110");
        PC1.setRAM(16);
        PC1.setPrecio(15000);
        System.out.println("Grafica: " + PC1.getGrafica() );
        System.out.println("Procesador: " + PC1.getProcesador());
        System.out.println("Motherboard: " + PC1.getMotherboard());
        System.out.println("Fuente de poder: " + PC1.getFuente());
        System.out.println("RAM: " + PC1.getRAM());
        System.out.println("Precio: " + PC1.getPrecio() + "+ IVA: 2,400" );
    }
    
}

class computadora{
    private String grafica;
    private String procesador;
    private String motherboard;
    private String fuente_poder;
    private double precio;
    private int ram;
    
    public void setGrafica(String valor){
      grafica = valor;  
    }
    public String getGrafica(){
        return grafica;
    }
    public void setProcesador(String valor){
        procesador = valor;
    }
    public String getProcesador(){
        return procesador;
    }
    public void setMotherboard(String valor){
        motherboard = valor;
    }
    public String getMotherboard(){
        return motherboard;
    }
    public void setFuente(String valor){
        fuente_poder = valor;
    }
    public String getFuente(){
        return fuente_poder;
    }
    public void setPrecio(double valor){
        precio = valor;
    }
    public double getPrecio(){
        return precio;
    }
    public void setRAM(int valor){
        ram = valor; 
    }
    public int getRAM(){
        return ram;
    }
            
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva2_12_herencia;

/**
 *
 * @author Alex Montes
 */
public class EVA2_1_HERENCIA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        
    }
    
class Estudiante extends Persona{
    private String nombre;
    private int edad;
    private String numeroControl;

    public String getNumeroControl() {
            return numeroControl;
        }

    public void setNumeroControl(String numeroControl) {
            this.numeroControl = numeroControl;
        }
    
    public Estudiante(){
        this.nombre = "";
        this.edad = 0;
    }
    
    public Estudiante(String nombre, int edad){
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
    }
   

    


}

class Persona{
    private String nombre;
    private int edad;
    
    public Persona(){
        this.nombre = "";
        this.edad = 0;
    }
    
    public Persona(String nombre, int edad){
        this.nombre = nombre;
        this.edad = edad;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
}
class Maestro extends Persona{
    private int numRegistro;
    
    public Maestro(){
        super();
        System.out.println("clase Maestro");
    }
    public Maestro(int numRegistro, String nombre, int edad){
        super(nombre, edad);
        this.numRegistro = numRegistro;
    }

    public int getNumRegistro() {
        return numRegistro;
    }

    public void setNumRegistro(int numRegistro) {
        this.numRegistro = numRegistro;
    }
    @override
    public void imprimirDatos(){
        super.imprimirDatos();
         System.out.println("No. de registro: " + numRegistro);
    }
} 
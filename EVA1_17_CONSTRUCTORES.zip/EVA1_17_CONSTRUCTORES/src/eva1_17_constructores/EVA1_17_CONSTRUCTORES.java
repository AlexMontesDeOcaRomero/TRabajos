/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_17_constructores;

/**
 *
 * @author Alex Montes
 */
public class EVA1_17_CONSTRUCTORES {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona persona = new Persona();
        System.out.println("Nombre: " + persona.getNombre());
        System.out.println("Edad: " + persona.getEdad());
        
        Persona persona2 = new Persona();
        System.out.println("Nombre: " + persona2.getNombre());
        System.out.println("Edad: " + persona2.getEdad());
        
        Persona persona3 = new Persona("Ruben", 40);
        System.out.println("Nombre: " + persona3.getNombre());
        System.out.println("Edad: " + persona3.getEdad()); 
        
        Persona persona4 = new Persona(5.0);
        System.out.println("Nombre: " + persona4.getNombre());
        System.out.println("Edad: " + persona4.getEdad());
        
    }
    
}
class Persona{
    private String nombre;
    private int edad;
    
    public Persona(){
        System.out.println("creando el objeto");
        nombre = "Juan Perez";
        edad = 100;
    }
    //sobre carga de metodos
    public Persona(String nombre, int edad){
      System.out.println("creando el objeto con constructor que acepta valores");
      this.nombre = nombre;
      this.edad = edad;
    }
    public Persona(double edad){
        System.out.println("creando el objeto con constructor que acepta doubles");
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }
    
}
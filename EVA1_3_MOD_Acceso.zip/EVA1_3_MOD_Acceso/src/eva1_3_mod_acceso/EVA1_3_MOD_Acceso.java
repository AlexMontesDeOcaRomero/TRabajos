/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_3_mod_acceso;

/**
 *
 * @author Alex Montes
 */
public class EVA1_3_MOD_Acceso {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Persona per1 = new Persona();//instancia crear un objeto
        per1.setId("21550348");
        per1.setNombre("Alexandro");
        per1.setEdad(18);
        System.out.println("Nombre: " + per1.getNombre());
        
        Persona per2 = new Persona();
        per2.setId("546545");
        per2.setNombre("Ruben");
        per2.setEdad(40);
        System.out.println(per2.getNombre() + ", " +);
    }
    
}

class Persona{
    //Atributos (VAriables)
    private String id;
    private String nombre;
    private int edad;
    //Comportamiento(Metodos)
    public String getId(){
        return id;
    }
    public String getNombre(){
        return nombre;
    }
    public int getEdad(){
        return edad;
    }
    public void setId(String valor){
        id = valor;
    }
    public void setNombre(String valor){
        nombre = valor;
    }
    public void setEdad(int valor){
        edad = valor;
    }
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_4_clase_auto2;

/**
 *
 * @author Alex Montes
 */
public class EVA1_4_CLASE_AUTO2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Automovil miAuto = new Automovil();
        miAuto.setMarca("Toyota");
        miAuto.setModelo("Supra");
        miAuto.setTipo("Deportivo");
        miAuto.setAno(1998);
        miAuto.setColor("dorado");
        miAuto.setPrecio(1200500.00);
        System.out.println("Marca: " + miAuto.getMarca());
        System.out.println("Modelo: " + miAuto.getModelo());
        System.out.println("Tipo: " + miAuto.getTipo());
        System.out.println("Año: " + miAuto.getAno());
        System.out.println("Color: " + miAuto.getColor());
        System.out.println("Precio: " + miAuto.getPrecio());
    }
    
}

class Automovil{
    //ATRIBUTOS PRIVADOS
    private String marca;
    private String modelo;
    private String Tipo;
    private int ano;
    private String color;
    private double precio;
    //COMPORTAMIENT
    //METODOS SET/GET
    public void setMarca(String valor){
        marca = valor;
    }
    public String getMarca(){
        return marca;
    }
    public void setModelo(String valor){
        modelo = valor;
    }
    public String getModelo(){
      return modelo;
    }
    public void setTipo(String valor){
        Tipo = valor;
    }
    public String getTipo(){
        return Tipo;
    }
    public void setAno(int valor){
        ano = valor;
    }
    public int getAno(){
        return ano;
    }
    public void setColor(String valor){
        color = valor;
    }
    public String getColor(){
        return color;
    }
    public void setPrecio(double valor){
        precio = valor;
    }
    public double getPrecio(){
        return precio;
    }
    public void imprimirDatos(){
        
    }
}
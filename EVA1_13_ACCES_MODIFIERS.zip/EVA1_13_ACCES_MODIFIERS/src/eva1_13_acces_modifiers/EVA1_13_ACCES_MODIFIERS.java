/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_13_acces_modifiers;

import Vehiculos_sin_motor.Bici;

/**
 *
 * @author Alex Montes
 */
public class EVA1_13_ACCES_MODIFIERS {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Automovil miCarro = new Automovil();
        miCarro.setAno(1990);
        Bici miBici = new Bici();
    }
    
}

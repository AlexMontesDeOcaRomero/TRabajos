/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_18_sobrecarga;

/**
 *
 * @author Alex Montes
 */
public class EVA1_18_SOBRECARGA {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        System.out.println("Hola mundo");
        Prueba obj = new Prueba();
        System.out.println(obj);
        System.out.println(100);
        System.out.println("Area de un rectangulo de 15 x 20" + calcularArea(15, 20));
        System.out.println("Area de un circulo de radio 100" + calcularArea(100));
    }
    public static double calcularArea(double base, double altura){
        return base * altura;
    }
    public static double calcularArea(double radio){
        return Math.PI * Math.pow(radio, 2);
    } 
    public static double calcularArea(int esTriangulo, double base, double altura){
        return (base * altura) / 2
    }
}

class Prueba{
    
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva_1_14_static;

/**
 *
 * @author Alex Montes
 */
public class EVA_1_14_STATIC {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        double area = FormulasMatematicas.calcularAreaCirculo(100);
        System.out.println("Area del circulo: " + area);
        double areaT = FormulasMatematicas.calcularAreaTriangulo(100, 50);
        System.out.println("Area del triangulo: " + areaT);
        FormulasMatematicas miObj = new FormulasMatematicas();
        miObj.imprimirMensaje();
    }
    
}

class FormulasMatematicas{
    int valor = 100;
    public static double calcularAreaCirculo(double radio){
        //area triangulo
        double area;
        area = 3.1416 * radio * radio;
        return area;
    }
    public static double calcularAreaTriangulo(double base, double altura){
        double area;
        area =(base* altura) / 2.0;
        return area;
        
    }
    public void imprimirMensaje(){
        System.out.println("Hola mundo");
    }
}
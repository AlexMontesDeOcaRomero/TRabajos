/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_15_formulas_temp;

import java.util.Scanner;

/**
 *
 * @author Alex Montes
 */
public class EVA1_15_FORMULAS_TEMP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner (System.in);
        System.out.println("Introduce los grados centigrados: ");
        double celcius = input.nextDouble();
        double fahrenheit = Conversiones.convertirCelaFar(celcius);
        double kelvin = Conversiones.convertirCelaKel(celcius);
        System.out.println(celcius + "C, " + fahrenheit + "F, " + kelvin + "K");
        System.out.println(fahrenheit + "F, " + kelvin + "K ");
        System.out.println(kelvin + "K, " + fahrenheit + "F");
    }
    
}
class Conversiones{
 public static double convertirCelaFar(double celcius){
     return celcius * 1.8 + 32.0;
     
 }
 public static double converitrFaraCel(double fahrenheit){
     return (fahrenheit - 32.0)/1.8;
     
 }
 public static double converitrFaraKel(double fahrenheit){
     return 5/9 * (fahrenheit - 32.0) + 273.15;
     
 }
 public static double convertirCelaKel(double celcius){
     return celcius + 273.15;
     
 }
  public static double convertirKelaCel(double kelvin){
      return kelvin - 273.15;
      
  }
  public static double convertirKelaFar(double kelvin){
      return 1.8 * (kelvin - 273.15) + 32.0;
  }
}

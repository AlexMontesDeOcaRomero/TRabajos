/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package eva1_7_memoria_1;

/**
 *
 * @author Alex Montes
 */
public class EVA1_7_MEMORIA_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int valor = 5;
        String cade = "hola";
        Prueba obj = new Prueba();
        
        System.out.println();
    }
    
}
class Prueba{
    public int x = 100;
    public void saludar(){
        
    }
}